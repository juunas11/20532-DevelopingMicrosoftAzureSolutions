Configuration AzureDev
{
	Import-DSCResource -Module xSystemSecurity -Name xIEEsc

	param ($MachineName)

	Node $MachineName
	{
		#Install IIS
		WindowsFeature IIS
		{
			Ensure = �Present�
			Name = �Web-Server�
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP
		{
			Ensure = �Present�
			Name = �Web-Asp-Net45�
		}

		#Install IIS Management Console
		WindowsFeature WebServerManagementConsole
		{
			Ensure = "Present"
			Name = "Web-Mgmt-Console"
		}
		
		#Disable IE Enhanced Security Configuration	for Admins 
		xIEEsc EnableIEEscAdmin
        {
            UserRole  = "Administrators"
            IsEnabled = $False
        }
		
		#Disable IE Enhanced Security Configuration	for Users
        xIEEsc EnableIEEscUser
        {
            UserRole  = "Users"
            IsEnabled = $True
		}
  
		#Install Web Platform Installer
		Package WebPi_Installation
		{
			Ensure = "Present"
			Name = "Microsoft Web Platform Installer 5.0"
			Path = Join-Path $PSScriptRoot wpilauncher.exe
			ProductId = '4D84C195-86F0-4B34-8FDE-4A17EB41306A'
			Arguments = ''
		}	
	  
		#Install Azure PowerShell
		Package AzurePowerShell_Installation
		{
			Ensure = "Present"
			Name = "Azure PowerShell"
			Path = "$env:ProgramFiles\Microsoft\Web Platform Installer\WebPiCmd-x64.exe"
			ProductId = ''
			Arguments = "/install /products:WindowsAzurePowerShell /accepteula"
			DependsOn = @("[Package]WebPi_Installation")
		}

		#Install Visual Studio 2013 & Azure SDK 2.6
		Package VisualStudio_Installation
		{
			Ensure = "Present"
			Name = "Visual Studio 2013 Community Edition"
			Path = "$env:ProgramFiles\Microsoft\Web Platform Installer\WebPiCmd-x64.exe"
			ProductId = ''
			Arguments = "/install /products:vs2013communityazurepack.2.6 /accepteula /forcereboot"
			DependsOn = @("[Package]WebPi_Installation")
		}
	}
} 