Configuration AzureDev
{
  param ($MachineName)

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
    }

    WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
  
    Package WebPi_Installation
    {
        Ensure = "Present"
        Name = "Microsoft Web Platform Installer 5.0"
        Path = Join-Path $PSScriptRoot wpilauncher.exe
        ProductId = '4D84C195-86F0-4B34-8FDE-4A17EB41306A'
        Arguments = ''
    }

    Package VisualStudio_Installation
    {
        Ensure = "Present"
        Name = "Visual Studio 2013 Community Edition"
        Path = "$env:ProgramFiles\Microsoft\Web Platform Installer\WebPiCmd-x64.exe"
        ProductId = ''
        Arguments = "/install /products:vs2013communityazurepack.2.6 /accepteula"
        DependsOn = @("[Package]WebPi_Installation")
    }	
	  
    Package AzurePowerShell_Installation
    {
        Ensure = "Present"
        Name = "Azure PowerShell"
        Path = "$env:ProgramFiles\Microsoft\Web Platform Installer\WebPiCmd-x64.exe"
        ProductId = ''
        Arguments = "/install /products:WindowsAzurePowerShell /accepteula"
        DependsOn = @("[Package]WebPi_Installation")
    }  
  }
} 